# WCML-HNB-MultiCurrency
HNB (Croatian National Bank) exchange rate for WPML WooCommerce Multilingual Multi Currency shop's.
